package com.example.idkwhatodo

class DataList(val img: Int, val strName:String, val strTelephoneNo:String){}